study_goals = []
tasks = []